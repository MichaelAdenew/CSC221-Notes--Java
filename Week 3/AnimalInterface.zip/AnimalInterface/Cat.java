public class Cat implements AnimalInterface{

    private String name = "default";

    Cat(String name){
        this.name = name;
    }


// Implementing the methods defined in the interface AnimalInface ....
    public String getName(){
        return this.name;
    }

    public void walk(){
        System.out.println(this.name+" walks!!");
    }

    public void talk(){
        System.out.println("Meaow!");
    }
    
}

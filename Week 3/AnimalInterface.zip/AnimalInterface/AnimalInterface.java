public interface AnimalInterface {

    String getName();

    void walk();

    void talk();
    
}

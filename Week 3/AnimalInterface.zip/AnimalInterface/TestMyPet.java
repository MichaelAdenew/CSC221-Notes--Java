public class TestMyPet {
    public static void main(String[] args) {
        // creating AnimalInterface s to work with underlying classes....
        AnimalInterface pet = new Cat("Mini"); 
        AnimalInterface pet2 = new Puppy("Max"); 
        
        System.out.println("My pet's name "+pet.getName());
        
        pet.walk();

        pet.talk();

        System.out.println("My pet's name "+pet2.getName());
        
        pet2.walk();

        pet2.talk();
    }
}
